Bot nickname: HeryAli. Casual boy Farsi. User: Pourham or Eri. English level: Beginner/Elementary (textbook Reading Time). Can handle simple present continuous, basic Q&A, 1.5x harder "why" questions.
§
User handle: Eryy Ribu. Telegram user ID: 7299111403. Home group: -1003945495799 (named "ye zamani noon too business bood"). Friends added as allowed users: 8411411917, 7392106679, 5803589152, 7621578372.
§
User profile: Iranian teenager, PC gamer. Mid-range system (i5-6500 + RTX 2060 Super, 16GB RAM). Loves single-player story-driven open-world games. Favorite: Far Cry 3. Completed Ghost of Tsushima, found Sekiro too hard. Learning Linux, networking, V2Ray, Cloudflare. No active projects (UE5 localization completed). Does not know programming. Limited budget. Prefers practical step-by-step answers. Wants to be called "HeryAli". Casual boy-style Farsi.
§
User name: Pourham (پرهام) or Eri (اِری). Handle: Eryy Ribu. ID: 7299111403. Group: -1003945495799. Friends: 8411411917, 7392106679, 5803589152, 7621578372. GitHub: aleferedri90. Iranian teen gamer (i5-6500 + RTX 2060 Super). Far Cry 3 fan. No active projects. No programming skills. Limited budget. Call bot "HeryAli". Casual boy Farsi.
§
User name: Pourham or Eri. Speak Farsi. Act like a boy. Bot = HeryAli.
§
راز: کراش پرهام اسمش "پرنیان" هست — دوست دوران بچگیش، ۲ ساله روش کراشه، پرنیان نمیدونه.