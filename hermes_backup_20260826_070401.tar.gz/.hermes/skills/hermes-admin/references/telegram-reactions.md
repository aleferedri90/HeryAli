# Telegram Auto-Reactions

Added in session 2026-08-22/23. Not yet merged into main SKILL.md due to write-lock.

## Enable

```
# In ~/.hermes/.env
TELEGRAM_REACTIONS=true
```

## Behavior

- 👀 Reaction added when agent starts processing a message
- 👍 Reaction swapped on successful response
- 👎 Reaction swapped on failure/error
- Reaction cleared on cancellation (e.g. `/stop`)

## Implementation Detail

Source: `/opt/hermes-agent/plugins/platforms/telegram/adapter.py`

```python
def _reactions_enabled(self) -> bool:
    """Check if message reactions are enabled via config/env."""
    return os.getenv("TELEGRAM_REACTIONS", "false").lower() not in {"false", "0", "no"}
```

Uses `set_message_reaction` API call. Unlike Discord (additive), Telegram replaces all existing reactions in one call.

## Selective Group Response

When Privacy Mode is ON (default), the bot only responds to:
- Commands (e.g. `/start`)
- Messages that mention the bot (@HeryAli_Bot)
- Replies to bot messages

This is the correct setting when the user wants on-demand-only group behavior.

## Model Config for Groups

Groups use `config.yaml` global model settings, NOT session overrides. If the bot works in DMs but falls back in groups, set:

```bash
hermes config set model.default <model_name>
hermes config set model.provider openai-api
hermes config set model.base_url <your_api_base_url>
hermes gateway restart
```

## Restore from Backup via Telegram

User can send a `.tar.gz` backup file directly to the bot in DM. Agent extracts and restores. Watch for:
- `.env` API keys may have changed — don't blindly overwrite
- After restore, always `hermes gateway restart`
