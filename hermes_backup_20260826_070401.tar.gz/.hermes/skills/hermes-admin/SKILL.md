---
name: hermes-admin
description: "Hermes admin: backup, multi-user access, cron maintenance, group configuration."
version: 1.1.0
category: autonomous-ai-agents
tags: [hermes, backup, admin, telegram, cron, configuration, groups]
---

# Hermes Administration

Operational procedures for managing a deployed Hermes Agent instance: backups, access control, platform configuration, group setup, and cron maintenance.

## Backup & Restore

### Backup Script Pattern

Create a shell script at `~/.hermes/scripts/backup_to_github.sh` that:
1. Creates a timestamped `.tar.gz` of critical Hermes data
2. Pushes to a GitHub repo via HTTPS (port 22 may be closed)

**What to include in the backup tarball:**
- `.hermes/memories/` — user memory store
- `.hermes/config.yaml` — all settings
- `.hermes/auth.json` — OAuth tokens / credential pools
- `.hermes/cron/` — scheduled jobs
- `.hermes/sessions/` — session index
- `.hermes/skills/` — installed skills
- `.hermes/state.db` — canonical session store (SQLite + FTS5)
- `.hermes/kanban.db` — work queue
- `.hermes/.env` — API keys and secrets
- `.hermes/state/` — lifecycle state files
- `.hermes/gateway_state.json` — gateway state
- `.hermes/channel_directory.json` — channel routing

**What to skip:** logs/, cache/, image_cache/, audio_cache/ (regenerable)

### Cron Job Setup

```bash
# Script must be relative to ~/.hermes/scripts/
cronjob(action='create', name='hermes-daily-backup', schedule='0 0 * * *',
        script='backup_to_github.sh', no_agent=True)
```

### Pitfalls

- **Script path must be relative**: Cron jobs reject absolute paths for scripts. Use just the filename; it resolves under `~/.hermes/scripts/`.
- **Git branch name**: New repos default to `master`, not `main`. Check with `git ls-remote` before pushing. Use the actual branch name in `git push`.
- **HTTPS auth**: When SSH port 22 is closed, embed the token in the remote URL: `https://TOKEN@github.com/user/repo.git`
- **git pull before push**: Always `git pull origin <branch> --rebase || true` before committing to avoid conflicts with previous backups.

### Cron Job Management

```bash
# List all jobs
cronjob(action='list')

# Run a job immediately
cronjob(action='run', job_id='...')

# Pause/resume
cronjob(action='pause', job_id='...')
cronjob(action='resume', job_id='...')
```

## Telegram Multi-User Access

### Configuration

Control who can interact with the Hermes Telegram bot via the `TELEGRAM_ALLOWED_USERS` environment variable in `~/.hermes/.env`.

```
# Single user
TELEGRAM_ALLOWED_USERS=7299111403

# Multiple users (comma-separated)
TELEGRAM_ALLOWED_USERS=7299111403,123456789,987654321
```

### Finding Telegram User IDs

Tell users to message `@userinfobot` on Telegram — it replies with their numeric User ID.

### Steps to Add a User

1. Get their numeric User ID (from `@userinfobot`)
2. Add to `TELEGRAM_ALLOWED_USERS` in `~/.hermes/.env` (comma-separated)
3. Restart the gateway: `hermes gateway restart`

### Platform Allowlist Pattern

This same pattern applies to other platforms. The env var naming convention is `<PLATFORM>_ALLOWED_USERS`:
- `TELEGRAM_ALLOWED_USERS`
- `DISCORD_ALLOWED_USERS`
- `WHATSAPP_ALLOWED_USERS`
- `SLACK_ALLOWED_USERS`
- etc.

### Pitfalls

- **Empty = deny all**: An empty `TELEGRAM_ALLOWED_USERS` with no `GATEWAY_ALLOW_ALL_USERS` set means nobody can DM the bot.
- **User IDs are numeric**: Telegram user IDs are integers, not usernames.
- **Restart required**: Changes to `.env` require a gateway restart to take effect.

## Telegram Group Configuration

### Adding Bot to a Group

1. Open the group in Telegram
2. Tap group name → **Add Members**
3. Search the bot username and add it
4. **Make the bot Admin** with these permissions:
   - ✅ Delete messages
   - ✅ Pin messages
   - ✅ Manage video chats
   - ✅ Add members

### Privacy Mode (Critical for Groups)

When **Privacy Mode** is ON (default), the bot only sees:
- Commands (e.g. `/start`)
- Messages that mention the bot
- Replies to bot messages

When **Privacy Mode** is OFF, the bot sees ALL group messages.

**Disable Privacy Mode via BotFather:**
1. Message `@BotFather`
2. `/mybots` → select your bot
3. `Bot Settings` → `Group Privacy` → **Turn off**

### Model Configuration for Groups

If the bot works in DMs but falls back to a wrong model in groups, the global model config is missing.

**Pitfall:** Groups use `config.yaml` model settings, not session overrides. Without them, the gateway logs show:
```
No model configured — defaulting to <fallback_model> for provider openrouter
```

**Fix — set model globally in config.yaml:**
```bash
hermes config set model.default <model_name>
hermes config set model.provider openai-api
hermes config set model.base_url <your_api_base_url>
```

Then restart the gateway.

**Verify:** Check gateway logs after restart — group messages should show `model=<your_model>` instead of fallback.

### Channel Directory

After adding the bot to groups, check the channel directory to verify registration:
```bash
cat ~/.hermes/channel_directory.json
```

Groups appear as entries with negative chat IDs (e.g. `-1003945495799`).

## Useful Commands

```bash
# Show full config
hermes config show

# Edit config interactively
hermes config edit

# Set a config value
hermes config set <key> <value>

# Check for config issues
hermes config check

# List connected platforms
hermes config show  # see "Messaging Platforms" section
```