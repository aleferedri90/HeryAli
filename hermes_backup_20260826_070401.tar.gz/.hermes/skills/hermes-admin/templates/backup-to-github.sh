#!/bin/bash
set -e

# Hermes Backup to GitHub Script
# Place at: ~/.hermes/scripts/backup_to_github.sh
# Schedule with: cronjob(action='create', script='backup_to_github.sh', schedule='0 0 * * *', no_agent=True)

BACKUP_DIR="/data/.hermes/backup"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="hermes_backup_$TIMESTAMP.tar.gz"

mkdir -p "$BACKUP_DIR"

# Create tarball of critical hermes data
tar -czf "$BACKUP_DIR/$BACKUP_FILE" \
    -C /data \
    .hermes/memories \
    .hermes/config.yaml \
    .hermes/auth.json \
    .hermes/cron \
    .hermes/sessions \
    .hermes/skills \
    .hermes/state.db \
    .hermes/kanban.db \
    .hermes/.env \
    .hermes/state \
    .hermes/gateway_state.json \
    .hermes/channel_directory.json \
    2>/dev/null || true

# Change to the backup directory
cd "$BACKUP_DIR"

# Initialize git if not already
if [ ! -d ".git" ]; then
    git init
    git remote add origin https://YOUR_TOKEN@github.com/YOUR_USER/YOUR_REPO.git
    git config user.email "backup@hermes.local"
    git config user.name "Hermes Backup"
fi

# Pull latest to avoid conflicts
git pull origin master --rebase || true

# Add the backup file
git add "$BACKUP_FILE"

# Commit
git commit -m "Backup $TIMESTAMP"

# Push
git push origin master
