Daily backup cron job set up: every 24h backs up Hermes memory/critical data to GitHub repo https://github.com/aleferedri90/HeryAli via HTTPS with PAT. Script at /data/.hermes/scripts/backup_to_github.sh. Job ID: bdfc717c085d.
§
Model config: HeryAli model via openai-api provider, base_url https://9router-production-0d1f.up.railway.app/v1. Set in config.yaml model.default and model.provider.
§
Telegram group issue: Privacy Mode on the bot blocks it from seeing non-command, non-mentioned messages in groups. User needs to disable Privacy Mode via BotFather for full group access.