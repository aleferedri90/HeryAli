User prefers: Casual boy Farsi. Say "چخبرا" not "چی میخوای". Don't say "ذخیره کنم?" — only save when user asks. Keep banter light. Don't talk much in groups. "س" = سلام (shorthand).
§
User handle: Eryy Ribu. Telegram user ID: 7299111403. Home group: -1003945495799 (named "ye zamani noon too business bood"). Friends added as allowed users: 8411411917, 7392106679, 5803589152, 7621578372.
§
Build Telegram userbot GUIs: PyWebView frameless HTML/CSS UIs with Telethon backend. Persian font: Tahoma.
§
Razz: Parnian (Pourham's crush, childhood friend). She lives in Tehran, he's in Bandar Anzali. Both 14yo. Families are friends. Never messaged each other. He found her number but hasn't texted. Her mom limits her (study focus). She reads manwha (romance/fantasy, not action). He wants to invite her family again and make up for not offering coffee last time. Key moments: head on his shoulder watching clips, insisted on staying, hugged from behind looking at photos. Maaani says confess, Pourham is scared.
§
User profile: Pourham (Eri), 14yo, Bandar Anzali. i5-6500 + RTX 2060 Super, Windows 10. Python 3.13 (MS Store). Learning Python + building Telethon userbot GUI (PyWebView). Groups: -1003945495799, -1003959495462, -5327958959. Schedule: Sun/Tue/Thu gym, Sun/Tue language class, daily online class for SAMAD exam, school starts in ~20 days. Wants to learn Python too.