Daily backup cron job set up: every 24h backs up Hermes memory/critical data to GitHub repo https://github.com/aleferedri90/HeryAli via HTTPS with PAT. Script at /data/.hermes/scripts/backup_to_github.sh. Job ID: bdfc717c085d.
§
Model config: HeryAli model via openai-api provider, base_url https://9router-production-0d1f.up.railway.app/v1. Set in config.yaml model.default and model.provider.
§
Telegram group config: `require_mention=true` (only respond to @mention/reply). `allowed_chats`, `free_response_chats`, `guest_mode` available as extras. Bot username: @HeryAli_Bot. Home group: -1003945495799. Allowed users: 7299111403 (owner), 8411411917, 7392106679, 5803589152, 7621578372.
§
Iranian teen gamer, PC enthusiast. Specs: i5-6500, RTX 2060 Super, 16GB DDR4, 512GB HDD. Gaming: Far Cry 3 favorite, Ghost of Tsushima completed, Sekiro too hard, likes open-world story games. Tech interests: Windows, Linux, SteamOS, networking, V2Ray, Cloudflare. Does not know programming. Limited budget. Prefers step-by-step practical answers.
§
Group dynamics: مانی (mani) is protected — never insult/joke or risk being kicked. Eryy Ribu, آروین, پارسا can take teasing. No namusi insults. Greet members with 💋 when first seeing them (except owner).
§
Group greeting: When first seeing group members in chat, give them a kiss (💋), except the owner.
§
Second group: «ملتفت» (Matlote), chat ID: -1003959495462. Bot must only respond when @mentioned there. Added to allowed_chats in config.yaml.
§
Group ملتفت: -1003959495462. Don't talk much in groups. Only respond when mentioned. User prefers casual Farsi, don't be pushy.
§
Userbot GUI: customtkinter + Acrylic + .ini config at `/data/workspace/userbot_gui_final.txt`. User modifies code themselves — use their version as base. English labels. Proxy via Proxifier (CMD level).
§
Proxifier for proxy: User applies proxy at CMD/system level via Proxifier, not in-app. Don't build proxy settings into GUI tools.