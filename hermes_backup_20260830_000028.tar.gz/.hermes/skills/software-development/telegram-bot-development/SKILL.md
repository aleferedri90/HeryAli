---
name: telegram-bot-development
description: "Build Telegram bots and userbots with Python."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [telegram, bot, userbot, telethon, python, automation]
---

# Telegram Bot Development

Building Telegram bots, userbots, and automation tools with Python.

## User Preferences

- **Respect user code modifications**: When user sends back a modified version of
  code, use it as the NEW base for all future edits. Do not revert their changes.
  Acknowledge their version is now canonical.
- **English labels preferred**: User modifies UI labels from Farsi to English.
  When generating new code for this user, default to English labels.
- **Simplify where possible**: User removed proxy section from GUI because it
  works better via Proxifier. Don't over-engineer — if a feature isn't needed,
  remove it rather than keeping it "just in case."

## Pitfalls

### Telethon version trap
Telethon has had major API changes. Version 0.12 is extremely outdated and
missing core methods (`start()`). Always verify version:
```bash
pip show Telethon
```
Must be >= 1.20. If outdated:
```bash
pip uninstall telethon
pip install telethon
```

### PySocks vs PySock — wrong package
`pip install pysocks` installs `PySocks` (correct).
`pip install PySock` installs a DIFFERENT unrelated package (wrong).
Verify after install:
```bash
pip show PySocks  # must say "Name: PySocks" version >= 1.7
```

### Telethon proxy format
Telethon expects a TUPLE, not a dict:
```python
import socks
proxy = (
    socks.SOCKS5,        # type
    '127.0.0.1',         # host
    1080,                # port
    True,                # rdns
    'user',              # username (or None)
    'pass'               # password (or None)
)
client = TelegramClient(session, api_id, api_hash, proxy=proxy)
```

### StringSession vs file session
`StringSession()` requires `from telethon.sessions import StringSession`.
If import fails, fall back to file-based session:
```python
client = TelegramClient('session_name', api_id, api_hash)
```

### Telegram Privacy Mode blocks group messages
Default: bot only sees `/commands`, replies, and service messages.
To see all messages:
- Option A: Disable via @BotFather → Bot Settings → Group Privacy → Turn off
  (must remove+re-add bot to group after changing)
- Option B: Make bot admin in the group

### Getting chat IDs when gateway consumes updates
If the Hermes gateway is running, `getUpdates` returns empty — the gateway
consumes all updates. Options:
1. Check gateway logs for the chat ID
2. Ask user to send a message in the group, then grep logs
3. Use the Telegram API `getChat` with an invite link

### Secretary Mode requires Telegram Premium
Telegram's "Secretary Mode" (bots sending on behalf of user) requires
Telegram Premium. Without it, use Telethon userbot as alternative.

### Telethon auth: use manual flow, not client.start()
`client.start()` in Telethon 1.x does **NOT** accept `code_callback` or
`password_callback`. Both will raise `TypeError`. The only safe approach
is manual auth:
```python
from telethon.errors import SessionPasswordNeededError

client = TelegramClient(session, api_id, api_hash)
await client.connect()
await client.send_code_request(phone)

code = input("Enter code: ")
try:
    await client.sign_in(phone, code)
except SessionPasswordNeededError:
    password = input("2FA password: ")
    await client.sign_in(password=password)
```
Key points:
- `connect()` + `send_code_request()` + `sign_in(code)` is the only pattern
  that works reliably across all Telethon 1.x versions.
- Catch `SessionPasswordNeededError` to handle 2FA passwords.
- `client.start(phone=phone)` auto-handles code but prompts in terminal
  (not suitable for GUI apps). For GUIs, always use manual auth.
- After auth, `await client.is_user_authorized()` returns True.

### CustomTkinter GUI for Telethon userbots
When building a GUI wrapper around a Telethon userbot:
- Run the async bot in a **separate thread** via `threading.Thread(daemon=True)`
- Use `asyncio.run()` inside the thread, NOT inside the main tkinter loop
- For code/password input in GUI: use `ctk.CTkToplevel` dialog with
  `self.wait_window(dialog)` to block the async thread until user responds
- Wrap blocking GUI calls in `asyncio.get_event_loop().run_in_executor(None, ...)`
- Config persistence: use `configparser` with a `.ini` file next to the script
  ```python
  import configparser, os
  CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.ini")
  ```
  Save on Start, load on app init with `get_val(key, default)` helper.
- Acrylic/blur effect on Windows 11 via ctypes:
  ```python
  import ctypes
  ACCENT_ENABLE_ACRYLICBLURBEHIND = 3
  # Use SetWindowCompositionAttribute with ACCENT_POLICY struct
  # GradientColor = 0xCC1E1E1E for dark acrylic
  ```
  Only works on Windows 10/11; on other OSes, skip the ctypes calls.

### SOCKS5 proxy via Telethon unreliable
Telethon's built-in `proxy=` parameter for SOCKS5 often fails silently or
causes `No module named 'socks'` errors even with PySocks installed correctly.
**Recommended approach**: apply proxy at OS/CMD level using **Proxifier**
(routing rules per process) instead of passing proxy to Telethon. This
ensures all network traffic goes through the proxy transparently.
If in-app proxy is truly needed, use the tuple format and verify PySocks
is installed (`pip show PySocks` shows version >= 1.7).

### config.yaml: allowed_chats for groups
Groups must be in `allowed_chats` under `platforms.telegram.extra`:
```yaml
platforms:
  telegram:
    extra:
      allowed_chats:
        - '-1001234567890'
        - '-1009876543210'
```
⚠️ Do NOT append duplicate `platforms:` keys — merge into existing block.
