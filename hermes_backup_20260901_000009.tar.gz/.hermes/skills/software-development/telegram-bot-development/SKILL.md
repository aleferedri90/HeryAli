---
name: telegram-bot-development
description: "Build Telegram bots and userbots with Python."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [telegram, bot, userbot, telethon, python, automation]
---

# Telegram Bot Development

Building Telegram bots, userbots, and automation tools with Python.

## User Preferences

- **Respect user code modifications**: When user sends back a modified version of
  code, use it as the NEW base for all future edits. Do not revert their changes.
  Acknowledge their version is now canonical.
- **English labels preferred**: User modifies UI labels from Farsi to English.
  When generating new code for this user, default to English labels.
- **Simplify where possible**: User removed proxy section from GUI because it
  works better via Proxifier. Don't over-engineer — if a feature isn't needed,
  remove it rather than keeping it "just in case."
- **Don't rewrite from scratch**: When the user has an existing HTML/UI design,
  download/modify what they have rather than rewriting from scratch. Only swap
  CDN links for local vendor files, add new features, or fix bugs. Rewriting
  wastes time and introduces regressions. (User said: "از صفر ننویس فقط چیزایی
  که لازمه رو دانلود کن و یکاری کن تا لوکال استفاده کنه")
- **Don't proactively save memory**: Only save to memory when user explicitly
  asks. User finds "ذخیره کنم؟" annoying.

## Pitfalls

### Telethon version trap
Telethon has had major API changes. Version 0.12 is extremely outdated and
missing core methods (`start()`). Always verify version:
```bash
pip show Telethon
```
Must be >= 1.20. If outdated:
```bash
pip uninstall telethon
pip install telethon
```

### PySocks vs PySock — wrong package
`pip install pysocks` installs `PySocks` (correct).
`pip install PySock` installs a DIFFERENT unrelated package (wrong).
Verify after install:
```bash
pip show PySocks  # must say "Name: PySocks" version >= 1.7
```

### Telethon proxy format
Telethon expects a TUPLE, not a dict:
```python
import socks
proxy = (
    socks.SOCKS5,        # type
    '127.0.0.1',         # host
    1080,                # port
    True,                # rdns
    'user',              # username (or None)
    'pass'               # password (or None)
)
client = TelegramClient(session, api_id, api_hash, proxy=proxy)
```

### StringSession vs file session
`StringSession()` requires `from telethon.sessions import StringSession`.
If import fails, fall back to file-based session:
```python
client = TelegramClient('session_name', api_id, api_hash)
```

### Telegram Privacy Mode blocks group messages
Default: bot only sees `/commands`, replies, and service messages.
To see all messages:
- Option A: Disable via @BotFather → Bot Settings → Group Privacy → Turn off
  (must remove+re-add bot to group after changing)
- Option B: Make bot admin in the group

### Getting chat IDs when gateway consumes updates
If the Hermes gateway is running, `getUpdates` returns empty — the gateway
consumes all updates. Options:
1. Check gateway logs for the chat ID
2. Ask user to send a message in the group, then grep logs
3. Use the Telegram API `getChat` with an invite link

### Secretary Mode requires Telegram Premium
Telegram's "Secretary Mode" (bots sending on behalf of user) requires
Telegram Premium. Without it, use Telethon userbot as alternative.

### Telethon auth: use manual flow, not client.start()
`client.start()` in Telethon 1.x does **NOT** accept `code_callback` or
`password_callback`. Both will raise `TypeError`. The only safe approach
is manual auth:
```python
from telethon.errors import SessionPasswordNeededError

client = TelegramClient(session, api_id, api_hash)
await client.connect()
await client.send_code_request(phone)

code = input("Enter code: ")
try:
    await client.sign_in(phone, code)
except SessionPasswordNeededError:
    password = input("2FA password: ")
    await client.sign_in(password=password)
```
Key points:
- `connect()` + `send_code_request()` + `sign_in(code)` is the only pattern
  that works reliably across all Telethon 1.x versions.
- Catch `SessionPasswordNeededError` to handle 2FA passwords.
- `client.start(phone=phone)` auto-handles code but prompts in terminal
  (not suitable for GUI apps). For GUIs, always use manual auth.
- After auth, `await client.is_user_authorized()` returns True.

### CustomTkinter GUI for Telethon userbots
When building a GUI wrapper around a Telethon userbot:
- Run the async bot in a **separate thread** via `threading.Thread(daemon=True)`
- Use `asyncio.run()` inside the thread, NOT inside the main tkinter loop
- For code/password input in GUI: use `ctk.CTkToplevel` dialog with
  `self.wait_window(dialog)` to block the async thread until user responds
- Wrap blocking GUI calls in `asyncio.get_event_loop().run_in_executor(None, ...)`
- Config persistence: use `configparser` with a `.ini` file next to the script
  ```python
  import configparser, os
  CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.ini")
  ```
  Save on Start, load on app init with `get_val(key, default)` helper.
- Acrylic/blur effect on Windows 11 via ctypes:
  ```python
  import ctypes
  ACCENT_ENABLE_ACRYLICBLURBEHIND = 3
  # Use SetWindowCompositionAttribute with ACCENT_POLICY struct
  # GradientColor = 0xCC1E1E1E for dark acrylic
  ```
  Only works on Windows 10/11; on other OSes, skip the ctypes calls.
  Full working template for this session's GUI: see
  `references/telethon-gui-template.md` (manual auth, session persistence,
  .ini UTF-8, hamburger-sidebar UI, acrylic-transparent frames).

### SOCKS5 proxy via Telethon unreliable
Telethon's built-in `proxy=` parameter for SOCKS5 often fails silently or
causes `No module named 'socks'` errors even with PySocks installed correctly.
**Recommended approach**: apply proxy at OS/CMD level using **Proxifier**
(routing rules per process) instead of passing proxy to Telethon. This
ensures all network traffic goes through the proxy transparently.
If in-app proxy is truly needed, use the tuple format and verify PySocks
is installed (`pip show PySocks` shows version >= 1.7).

### Session persistence: use file-based session, not StringSession
`StringSession()` is in-memory only — lost on restart, forces re-auth every time.
For persistent sessions that survive restarts, use a file-based session:
```python
client = TelegramClient("session_name", api_id, api_hash)  # saves to session_name.session
```
The `.session` file is created next to the script. If the user hits "71885 seconds
wait" errors, they've been re-authing too many times because session isn't persisting.

### configparser encoding on Windows
On Windows, `config.read(file)` defaults to system encoding (cp1252), garbling
Persian/Arabic/emoji text in `.ini` files. ALWAYS pass encoding:
```python
config.read(CONFIG_FILE, encoding="utf-8")   # read
with open(CONFIG_FILE, "w", encoding="utf-8") as f:  # write
```
Without this, Farsi text becomes `ÃƒÆ'Ã†â€™ÃƒÂ¢Ã¢â‚¬Å¾` mojibake.

### Font for Persian/emoji in customtkinter
`Arial` does not render Persian/Farsi text or some emojis correctly in customtkinter.
Use `Tahoma` (Windows built-in, supports Arabic script + emoji):
```python
ctk.CTkLabel(frame, text="متن فارسی", font=("Tahoma", 14))
```

### is_user_authorized() — avoid unnecessary auth requests
Before calling `send_code_request()`, check if already authenticated:
```python
await client.connect()
if not await client.is_user_authorized():
    await client.send_code_request(phone)
    code = ...
    await client.sign_in(phone, code)
else:
    # already logged in, skip code request
```
This prevents hitting Telegram's rate limit ("71885 seconds wait") when session
file exists but code is still requested.

### customtkinter image assets (CTkImage + PIL)
When user provides image assets (PNG/JPG) for buttons/icons, use `CTkImage`:
```python
from PIL import Image
import customtkinter as ctk

ASSETS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")

self.img_start = ctk.CTkImage(
    light_image=Image.open(os.path.join(ASSETS_DIR, "start_btn.jpg")),
    size=(140, 40)
)
# Use in button:
ctk.CTkButton(frame, image=self.img_start, text="", ...)
# Use in label:
ctk.CTkLabel(frame, image=self.img_icon, text="")
```
- Always pass `text=""` when using image-only buttons (avoids text overlay)
- `size=(w, h)` controls display size regardless of original image dimensions
- Wrap in try/except with fallback to text buttons if assets missing

### Clipboard paste button
Add a paste-from-clipboard button next to text entries:
```python
def paste_from_clipboard(self, entry):
    try:
        text = self.clipboard_get()
        entry.delete(0, "end")
        entry.insert(0, text)
    except:
        pass

# In UI: add paste button next to each entry
paste_btn = ctk.CTkButton(row, image=self.img_paste, text="", width=30,
    command=lambda e=entry: self.paste_from_clipboard(e))
```

### tkinter-designer workflow
For visual GUI design without hand-coding layout:
1. Install: `pip install tkinter-designer`
2. Run: `python -m tkinter_designer design.fig`
3. If CLI not found, try `python -m tkinter_designer` or `tkdesigner`
   (command name varies by version — always use `python -m` form as fallback)
4. Export generates a `GUI.py` with layout code
5. Add business logic (Telethon, configparser, etc.) manually afterward
Best paired with Figma for visual design → export `.fig` → convert.
**Known issue**: Figma free tier has frame limits — if hit, use Canva or
hand-draw an sketch and describe layout to the agent.

### PyWebView: frameless HTML/CSS desktop apps
When user wants a modern UI with glass/acrylic effects, frameless window,
or HTML/CSS-based design → use PyWebView instead of customtkinter:
```bash
pip install pywebview
```
```python
import webview
window = webview.create_window(
    'App Title',
    'index.html',
    width=400, height=600,
    frameless=True,      # no title bar
    easy_drag=True,      # draggable via CSS -webkit-app-region: drag
)
webview.start()
```
**HTML/CSS frameless title bar pattern:**
```css
.titlebar {
    -webkit-app-region: drag;    /* makes this area draggable */
}
.titlebar button {
    -webkit-app-region: no-drag; /* buttons remain clickable */
}
```
**Settings persistence**: use `localStorage` in HTML/JS instead of .ini:
```javascript
localStorage.setItem('settings', JSON.stringify(data));
const saved = JSON.parse(localStorage.getItem('settings'));
```
**vs customtkinter**: PyWebView gives true glass/acrylic, frameless windows,
and modern CSS styling. customtkinter is limited by its opaque canvas.
Use PyWebView when visual quality matters; use CTk when simplicity matters.

#### ⚠️ Pitfall: `window.expose()` only accepts FUNCTIONS, not objects
```python
# ❌ BROKEN — TypeError: Parameter must be a function
api = Api(window)
window.expose(api)

# ✅ CORRECT — expose each method individually
window.expose(
    api.save_settings, api.load_settings,
    api.start_bot, api.stop_bot,
    api.close, api.log,
    api.submit_code, api.submit_password,
)
```

#### PyWebView ↔ Python bidirectional communication
**Python → JS**: `window.evaluate_js("jsFunction('arg')")`
**JS → Python**: `window.pywebview.api.python_method(arg)`

For async user input (e.g., code/password prompts) from a background thread:
```python
import threading

class Api:
    def __init__(self, window):
        self.window = window
        self._code_result = None
        self._code_event = threading.Event()

    # Called from JS when user submits
    def submit_code(self, code: str):
        self._code_result = code
        self._code_event.set()

    # Called from Python thread — shows modal and waits
    def prompt_code(self):
        self._code_result = None
        self._code_event.clear()
        self.window.evaluate_js("showCodeModal()")  # JS shows the modal
        self._code_event.wait(timeout=300)           # blocks until JS calls back
        return self._code_result
```
JS side:
```javascript
function showCodeModal() { /* show overlay */ }
function submitCode() {
    const code = document.getElementById('code-input').value;
    hideCodeModal();
    window.pywebview.api.submit_code(code);  // calls Python
}
```
This pattern avoids busy-waiting and works cleanly across Python threads.

### Google Stitch for UI design
Free AI tool from Google Labs that generates UI from text prompts or sketches:
→ [stitch.withgoogle.com](https://stitch.withgoogle.com)
- Prompt: "Dark themed desktop app with 3 text+timer rows, hamburger menu..."
- Export: HTML/CSS code → use with PyWebView for desktop app
- Also exports to Figma for further editing
**Workflow**: Stitch → export HTML → PyWebView → desktop app

### CustomTkinter Toplevel dialogs: fix ALL call sites when changing signature
If a helper like `ask(title, label, is_password=False)` requires two positional
args, EVERY call site must pass both. A single `self.ask("text")` call (missing
`label`) raises `TypeError: missing 1 required positional argument` at runtime —
only when that path executes. After changing a helper's signature, grep for all
callers and update them in one pass.

### Acrylic: what actually works in customtkinter (VERIFIED)
**CRITICAL LIMITATION**: customtkinter does NOT allow `fg_color="transparent"`
on the main `CTk` window — it raises
`ValueError: transparency is not allowed for this attribute`.
It IS allowed on `CTkFrame`/`CTkButton`/`CTkLabel` children, but children sit
on top of the opaque canvas, so making them transparent alone does NOT reveal
the blur — the root canvas always paints `fg_color` solid.

**Tested approaches (session-verified):**
1. **AccentState=3 (ACCRYLICBLURBEHIND)** — blurs inside the window over the
   solid canvas color. With low-alpha GradientColor (0x01000000), produces a
   subtle dark matte effect. Best reliable result with CTk.
2. **AccentState=4 (HOSTBACKDROP)** — blurs what is BEHIND the window (desktop).
   Should give iOS-glass look, but user reported "هیچ فرقی نکرد" (no difference)
   because CTk's root canvas still paints solid fg_color on top.
3. **DwmExtendFrameIntoClientArea** with MARGINS(-1,-1,-1,-1) — extends DWM
   glass frame into client area. Also tried, no visible difference because
   CTk's internal canvas paints over it.

**Working pattern:**
```python
accent.AccentState = 3
accent.GradientColor = 0x01000000  # very low alpha = subtle dark glass
```
Apply after window is drawn, re-apply for reliability:
```python
self.after(200, self.setup_acrylic)
self.after(600, self.setup_acrylic)
```

**Bottom line**: customtkinter's opaque canvas fundamentally prevents true
glass/acrylic transparency. The effect produces a subtle dark tint at best.
For real glass, consider: (a) raw tkinter without CTk, (b) PyQt6 with
Qt.WA_TranslucentBackground, or (c) Electron/Tauri with native blur APIs.

### PyWebView: frameless window minimize/close
Frameless PyWebView windows have no native title bar controls. Minimize and
close must be exposed as Python methods:
```python
class Api:
    def minimize(self):
        self.window.minimize()
    def close(self):
        self.running = False
        self.window.destroy()

# Expose to JS
window.expose(api.minimize, api.close, ...)
```
```html
<!-- Minimize button -->
<button onclick="if(window.pywebview)window.pywebview.api.minimize()">—</button>
<!-- Close button -->
<button onclick="if(window.pywebview)window.pywebview.api.close()">✕</button>
```

### PyWebView: rounded corners on Windows 10/11+
**Windows 11+** — use DWM API (native rounded corners):
```python
import ctypes
def enable_rounded_corners(hwnd):
    try:
        DWMWA_WINDOW_CORNER_PREFERENCE = 33
        DWMWCP_ROUND = 2
        attr = ctypes.c_int(DWMWCP_ROUND)
        ctypes.windll.dwmapi.DwmSetWindowAttribute(
            hwnd, DWMWA_WINDOW_CORNER_PREFERENCE,
            ctypes.byref(attr), ctypes.sizeof(attr)
        )
    except Exception:
        pass  # Windows 10 or older — silently skip
```
**Windows 10** — DWM approach silently fails. Use `SetWindowRgn` to clip:
```python
from ctypes import wintypes
def enable_rounded_corners(hwnd):
    try:
        rect = wintypes.RECT()
        ctypes.windll.user32.GetWindowRect(hwnd, ctypes.byref(rect))
        w = rect.right - rect.left
        h = rect.bottom - rect.top
        radius = 16
        region = ctypes.windll.gdi32.CreateRoundRectRgn(0, 0, w, h, radius*2, radius*2)
        ctypes.windll.user32.SetWindowRgn(hwnd, region, True)
    except Exception:
        pass
```
Get HWND via window title after a short delay (works for both approaches):
```python
def on_start(window):
    def _set_rounded():
        import time; time.sleep(0.5)
        hwnd = ctypes.windll.user32.FindWindowW(None, "App Title")
        if hwnd:
            enable_rounded_corners(hwnd)
    threading.Thread(target=_set_rounded, daemon=True).start()

webview.start(debug=False, func=on_start)
```
For the CSS to match, set body `background: transparent` and wrap content
in a div with `border-radius: 16px; overflow: hidden`.
⚠️ `SetWindowRgn` clips the window region — corners become transparent
(not rounded with a background). Works visually with transparent body + dark
app background.

### PyWebView: loading spinner while app initializes
Show a CSS spinner overlay while PyWebView loads. Hide it on `pywebviewready`:
```html
<div id="loading-screen">
    <div class="spinner"></div>
    <p>Loading...</p>
</div>
```
```css
#loading-screen {
    position: fixed; inset: 0; z-index: 999;
    background: #131313;
    display: flex; flex-direction: column;
    align-items: center; justify-content: center;
    transition: opacity 0.4s ease;
}
#loading-screen.hidden { opacity: 0; pointer-events: none; }
.spinner {
    width: 48px; height: 48px;
    border: 3px solid #3d4a3f;
    border-top-color: #5ddf88;
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }
```
```javascript
function hideLoading() {
    loadSettings();
    setTimeout(() => {
        document.getElementById('loading-screen').classList.add('hidden');
        setTimeout(() => document.getElementById('loading-screen').remove(), 500);
    }, 400);
}
if (window.pywebview) {
    window.addEventListener('pywebviewready', hideLoading);
} else {
    window.addEventListener('load', hideLoading);
}
```

### PyWebView: offline vendor pattern (no CDN at runtime)
When building PyWebView desktop apps, users on slow/offline machines will see
slow loads from CDN (Tailwind ~300KB, Google Fonts, Material Symbols).
Download vendor files locally and reference with relative paths:

```bash
mkdir -p vendor/fonts
curl -sL -o vendor/tailwind.js "https://cdn.tailwindcss.com/3.4.17"
curl -sL -o vendor/fonts/fonts.css "https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600&display=swap"
curl -sL -o vendor/fonts/material-symbols.css "https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined&display=swap"
```
Then parse the CSS files for `url(https://...)` references and download each
font file locally, replacing the URLs in the CSS with local filenames:
```python
import re, os, subprocess
for css_file in ['vendor/fonts/fonts.css', 'vendor/fonts/material-symbols.css']:
    content = open(css_file).read()
    for url in re.findall(r'url\((https?://[^)]+)\)', content):
        filename = url.split('/')[-1].split('?')[0]
        subprocess.run(['curl', '-sL', '-o', f'vendor/fonts/{filename}', url])
        content = content.replace(url, filename)
    open(css_file, 'w').write(content)
```
Update HTML `<script>` and `<link>` tags to point to `vendor/` paths.
**User correction**: do NOT rewrite HTML from scratch to remove CDN — just
download what's needed and swap the paths. Rewriting wastes time and
introduces bugs.

### PyWebView: fixed port for local server
PyWebView picks a random port for its internal server, which breaks
firewall rules and bookmarking. Use a custom HTTP server on a fixed port:
```python
import http.server, socketserver, threading
PORT = 33333

def start_server(base_dir):
    handler = http.server.SimpleHTTPRequestHandler
    os.chdir(base_dir)
    httpd = socketserver.TCPServer(("127.0.0.1", PORT), handler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    return httpd

httpd = start_server(os.path.dirname(os.path.abspath(__file__)))
window = webview.create_window('App', f'http://127.0.0.1:{PORT}/index.html', ...)
```
This also fixes relative path resolution for vendor/ files.

### PyWebView: clipboard permission dialog on every paste
`navigator.clipboard.readText()` in PyWebView triggers a browser permission
prompt ("Allow access to clipboard?") on EVERY click. Users find this annoying.
**Fix**: use Python's tkinter clipboard instead — no permission dialog:
```python
# In Python Api class
def get_clipboard(self):
    try:
        import tkinter as tk
        root = tk.Tk()
        root.withdraw()
        text = root.clipboard_get()
        root.destroy()
        return text
    except Exception:
        return ""
```
```javascript
// In JS — call Python instead of browser API
async function pasteTo(fieldId) {
    if (window.pywebview) {
        const text = await window.pywebview.api.get_clipboard();
        if (text) document.getElementById(fieldId).value = text;
    } else {
        // fallback for browser preview
        const text = await navigator.clipboard.readText();
        document.getElementById(fieldId).value = text;
    }
}
```

### PyWebView: use `pywebviewready` not `DOMContentLoaded`
`DOMContentLoaded` fires BEFORE `window.pywebview` is available. If you call
`pywebview.api.*` inside `DOMContentLoaded`, the API isn't ready and calls fail
silently (e.g., config.ini never loads).
```javascript
// ❌ BROKEN — pywebview not ready yet
document.addEventListener('DOMContentLoaded', loadSettings);

// ✅ CORRECT — wait for pywebview bridge
if (window.pywebview && window.pywebview.api) {
    window.addEventListener('pywebviewready', loadSettings);
} else {
    window.addEventListener('load', loadSettings);  // browser preview fallback
}
```
⚠️ **Even `pywebviewready` can fire before the API bridge is fully wired** —
always add a retry mechanism for critical init calls like loading config:
```javascript
function loadWithRetry(attempt) {
    attempt = attempt || 0;
    if (window.pywebview && window.pywebview.api) {
        loadSettings();
    } else if (attempt < 10) {
        setTimeout(() => loadWithRetry(attempt + 1), 200);
    }
}
// Also use as a safety net alongside pywebviewready:
setTimeout(loadWithRetry, 1000);
```

### PyWebView: hide CMD console window on Windows
Frameless PyWebView apps on Windows still show a console window behind
the app. Hide it at startup:
```python
import ctypes, sys
if sys.platform == "win32":
    try:
        hwnd = ctypes.windll.kernel32.GetConsoleWindow()
        if hwnd:
            ctypes.windll.user32.ShowWindow(hwnd, 0)
    except Exception:
        pass
```
Place this at the TOP of the script, before any other imports/calls.

### PyWebView: convert to .exe with PyInstaller
```bash
pip install pyinstaller
pyinstaller --onefile --noconsole \
    --add-data "index.html;." \
    --add-data "vendor;vendor" \
    --name "App-Name" \
    app.py
```
Output: `dist/App-Name.exe` (~30-40 MB with bundled Edge/WebKit engine).
Create a `build.bat` next to `app.py` for easy rebuilds:
```bat
@echo off
pyinstaller --onefile --noconsole --add-data "index.html;." --add-data "vendor;vendor" --name "Telethon-GUI" app.py
pause
```

### PyWebView: Load/Reset Settings buttons
Users often want explicit buttons to reload/save/clear config rather than
relying solely on auto-load. Add to sidebar:
```html
<button onclick="loadSettings()">Load Settings</button>
<button onclick="resetSettings()">Reset Settings</button>
```
```javascript
async function resetSettings() {
    if (window.pywebview) await window.pywebview.api.reset_settings();
    // Clear all fields
    ['api-id','api-hash','phone','chat-id','text-1','text-2','text-3',
     'timer-1','timer-2','timer-3'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = '';
    });
}
```
Python `reset_settings`: delete `config.ini` via `os.remove()`.

### config.yaml: allowed_chats for groups
Groups must be in `allowed_chats` under `platforms.telegram.extra`:
```yaml
platforms:
  telegram:
    extra:
      allowed_chats:
        - '-1001234567890'
        - '-1009876543210'
```
⚠️ Do NOT append duplicate `platforms:` keys — merge into existing block.
