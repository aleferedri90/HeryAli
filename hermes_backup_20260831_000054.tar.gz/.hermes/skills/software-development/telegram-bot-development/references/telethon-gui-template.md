# Telethon GUI Userbot — final working template (session-validated)

## Canonical file
`/data/workspace/userbot_gui_final.txt` in the originating session; on the
user's PC saved as `userbot_gui.py`. The user iterates on their own copy —
always treat their latest uploaded `.py` as the canonical base and apply
changes to it, never revert.

## Validated patterns (all confirmed working by user "عالی و کار کرد")

### Manual Telethon auth with GUI dialogs (Telethon 1.44.0)
```python
await client.connect()
if not await client.is_user_authorized():
    await client.send_code_request(phone)
    code = await asyncio.get_event_loop().run_in_executor(
        None, lambda: self.ask("Code", "Enter the Code Sent to your Telegram:"))
    try:
        await self.client.sign_in(phone, code)
    except SessionPasswordNeededError:
        password = await asyncio.get_event_loop().run_in_executor(
            None, lambda: self.ask("Password", "🔑 2FA Password:", is_password=True))
        await self.client.sign_in(password=password)
```
- `client.start(...)` does NOT accept code_callback/password_callback in 1.x.
- `is_user_authorized()` check prevents Telegram's "A wait of N seconds is
  required" (SendCodeRequest flood wait — user hit 71885s ≈ 20h).

### Session persistence
```python
session_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "userbot")
TelegramClient(session=session_file, ...)   # -> userbot.session next to script
```
`StringSession()` is in-memory — caused the repeated re-auth flood-wait.

### config.ini persistence (UTF-8 both ways on Windows)
```python
config.read(CONFIG_FILE, encoding="utf-8")   # READ — without it Persian/emoji mojibake ("ÃƒÆ'Ã†â€™...")
with open(CONFIG_FILE, "w", encoding="utf-8") as f: config.write(f)
```
No hardcoded defaults — all fields load from .ini via `get_val(key, default="")`.

### GUI structure (user's preferred UI, 3 rows)
- Top bar: ☰ hamburger (toggles sidebar via `place`/`place_forget`, lift() to top)
  + title + ✕ close button (red, corner_radius=15, command=self.destroy)
- Sidebar: API ID / API HASH / Phone Number / Chat ID + 💾 Save
- Main: 3 rows of "1st/2nd/3rd Text" (left, expand) + Timer (right, width=110)
- Logs box, then Start (green) / Stop (red) buttons
- Font: Tahoma everywhere (Persian + emoji safe; Arial is not)
- English labels/log messages (user's own choice)

### Acrylic glass effect (session-verified: limited by CTk)
ctypes `SetWindowCompositionAttribute` + ACCENT_POLICY.
**AccentState=3 is the most reliable with CTk** — produces subtle dark matte.
AccentState=4 and DwmExtendFrameIntoClientArea were tested but user confirmed
no visible difference because CTk's opaque root canvas paints over the blur.
```python
accent.AccentState = 3
accent.GradientColor = 0x01000000  # very low alpha for subtle dark glass
```
Apply twice: `self.after(200, ...)` and `self.after(600, ...)`.
⚠️ customtkinter does NOT allow `fg_color="transparent"` on the main `CTk`
window. For true glass, consider raw tkinter or PyQt6.

### Async in GUI
Bot loop in `threading.Thread(daemon=True)` running `asyncio.run(self.run_bot())`;
concurrent send loops via `asyncio.gather` on created tasks; Stop cancels tasks
and sets `self.running = False`.

### GUI structure (user's preferred UI, 3 rows)
- Top bar: ☰ hamburger (toggles sidebar via `place`/`place_forget`, lift() to top)
  + title + ✕ close button (red, corner_radius=15, command=self.destroy)
- Sidebar: API ID / API HASH / Phone Number / Chat ID + 💾 Save
- Main: 3 rows of "1st/2nd/3rd Text" (left, expand) + Timer (right, width=110)
  + paste button (CTkImage icon) next to each text entry
- Separator (CTkImage or styled frame)
- Logs box, then Start (green) / Stop (red) buttons (CTkImage or text)
- Font: Tahoma everywhere (Persian + emoji safe; Arial is not)
- English labels/log messages (user's own choice)

### Asset-based GUI with CTkImage
User provides image assets (buttons, icons, panels). Use CTkImage:
```python
from PIL import Image
ASSETS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
self.img_start = ctk.CTkImage(light_image=Image.open(f"{ASSETS_DIR}/start_btn.jpg"), size=(140,40))
ctk.CTkButton(frame, image=self.img_start, text="", ...)
```
Wrap in try/except with fallback to text buttons if assets missing.
Clipboard paste button: `self.clipboard_get()` → insert into entry.

## Errors encountered in-session (patterns, not unique bugs)
1. `AuthMethods.start() got unexpected keyword 'password_callback'` → manual auth.
2. `ask() missing 1 required positional argument 'label'` → fix all call sites.
3. Mojibake in .ini → encoding="utf-8" on read AND write.
4. Flood-wait 71885s → session file + is_user_authorized() guard.
5. `window.expose(api)` → TypeError: must expose individual methods, not object.

## PyWebView Telethon-GUI template (code + HTML modals for auth)
**Files:** `app.py` + `index.html`
- Python: `Api` class with `threading.Event` for sync between JS modals and Python auth
- HTML: Tailwind CSS dark theme, glass-panel, modal overlays for code + password
- Auth flow: `connect() → send_code_request() → JS modal → submit_code() → sign_in() → catch SessionPasswordNeededError → JS modal → submit_password() → sign_in(password)`
- JS→Python callback: `window.pywebview.api.submit_code(code)` triggers `threading.Event.set()`
- Python→JS prompt: `window.evaluate_js("showCodeModal()")` shows the overlay
