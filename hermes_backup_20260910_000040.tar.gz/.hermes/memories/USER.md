User prefers: Casual boy Farsi, light banter, don't talk much in groups. "س" = سلام. Lists to copy: plain lines no numbering.
§
User handle: Eryy Ribu. Telegram user ID: 7299111403. Home group: -1003945495799 (named "ye zamani noon too business bood"). Friends added as allowed users: 8411411917, 7392106679, 5803589152, 7621578372.
§
Build Telegram userbot GUIs: PyWebView frameless HTML/CSS UIs with Telethon backend. Persian font: Tahoma.
§
Razz: Parnian, Pourham's crush, childhood friend, Tehran. Both 14. Families friends. Never messaged. She reads manwha. Maaani says confess.
§
Pourham (Eri), 14yo, Bandar Anzali. i5-6500 + RTX 2060 Super, Win10. Python 3.13. Building Telethon userbot GUI (PyWebView). Groups: -1003945495799, -1003959495462, -5327958959. Schedule: gym Sun/Tue/Thu, lang Sun/Tue, daily SAMAD prep. School ~Sep 27.