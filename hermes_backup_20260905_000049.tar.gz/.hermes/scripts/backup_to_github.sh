#!/bin/bash
set -e

# Hermes Backup to GitHub Script
# Backs up critical Hermes data to GitHub repo via HTTPS

BACKUP_DIR="/data/.hermes/backup"
REPO_DIR="/data/.hermes/backup/repo"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="hermes_backup_$TIMESTAMP.tar.gz"
REPO_URL="https://aleferedri90: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@github.com/aleferedri90/HeryAli.git"

mkdir -p "$BACKUP_DIR"

# Create tarball of critical hermes data (exclude large/unnecessary files)
tar -czf "$BACKUP_DIR/$BACKUP_FILE" \
    -C /data \
    .hermes/memories \
    .hermes/config.yaml \
    .hermes/auth.json \
    .hermes/cron/jobs.json \
    .hermes/skills \
    .hermes/scripts \
    .hermes/.env \
    2>/dev/null || true

echo "✅ Backup created: $BACKUP_FILE ($(du -h "$BACKUP_DIR/$BACKUP_FILE" | cut -f1))"

# Clone or update the repo
if [ ! -d "$REPO_DIR/.git" ]; then
    echo "📥 Cloning repo..."
    rm -rf "$REPO_DIR"
    git clone "$REPO_URL" "$REPO_DIR" 2>/dev/null || {
        mkdir -p "$REPO_DIR"
        cd "$REPO_DIR"
        git init
        git remote add origin "$REPO_URL"
        git checkout -b main
    }
fi

cd "$REPO_DIR"
git config user.email "backup@hermes.local"
git config user.name "Hermes Backup"

# Pull latest
git pull origin main --rebase 2>/dev/null || git pull origin master --rebase 2>/dev/null || true

# Remove old backups (keep last 5)
ls -t hermes_backup_*.tar.gz 2>/dev/null | tail -n +6 | xargs rm -f 2>/dev/null || true

# Copy new backup
cp "$BACKUP_DIR/$BACKUP_FILE" .

# Add and commit
git add .
git commit -m "Backup $TIMESTAMP" --allow-empty 2>/dev/null || echo "No changes to commit"

# Push (force to handle branch name differences)
git push origin HEAD:main 2>/dev/null || git push origin HEAD:master 2>/dev/null || git push --force origin HEAD:main 2>/dev/null

echo "✅ Backup pushed to GitHub: $BACKUP_FILE"
