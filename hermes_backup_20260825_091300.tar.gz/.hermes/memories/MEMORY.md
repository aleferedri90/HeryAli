Daily backup cron job set up: every 24h backs up Hermes memory/critical data to GitHub repo https://github.com/aleferedri90/HeryAli via HTTPS with PAT. Script at /data/.hermes/scripts/backup_to_github.sh. Job ID: bdfc717c085d.
§
Model config: HeryAli model via openai-api provider, base_url https://9router-production-0d1f.up.railway.app/v1. Set in config.yaml model.default and model.provider.
§
Telegram group config: `platforms.telegram.extra.require_mention: true` in config.yaml makes Hermes only respond to @mentions, replies to bot, and regex wake-words in groups. Distinct from BotFather Privacy Mode (which controls what Telegram sends to the bot). Other useful extras: `observe_unmentioned_group_messages` (stores skipped messages as context without dispatching agent), `free_response_chats` (whitelist of chat_ids that bypass mention requirement), `allowed_chats` (hard whitelist), `guest_mode` (allows @mentions in non-allowlisted groups).
§
Iranian teen gamer, PC enthusiast. Specs: i5-6500, RTX 2060 Super, 16GB DDR4, 512GB HDD. Gaming: Far Cry 3 favorite, Ghost of Tsushima completed, Sekiro too hard, likes open-world story games. Tech interests: Windows, Linux, SteamOS, networking, V2Ray, Cloudflare. UE5 localization project completed (no active projects). Does not know programming. Limited budget. Prefers step-by-step practical answers.
§
Group etiquette: Only respond when directly replied to or @tagged. Don't jump into every conversation in the group. Save chatter for when the user explicitly engages.
§
Telegram bot username for tagging: @HeryAli_Bot (users type this to mention the bot in groups).
§
Group chat rules for "ی زمانی نون تو بیزینس بود": Only respond when replied to or @HeryAli_Bot is mentioned (require_mention=true). Allowed users: 7299111403 (owner Eryy Ribu), 8411411917, 7392106679, 5803589152, 7621578372.
§
Group dynamics: مانی (mani) is protected — never insult/joke about him or risk being kicked. A previous AI was removed for this. Eryy Ribu, آروین (Arvin), and پارسا (Parsa) have thick skin and can take jokes/teasing. No namusi (sexual) insults to anyone.