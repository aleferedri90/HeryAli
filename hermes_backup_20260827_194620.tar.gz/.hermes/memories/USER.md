User prefers: Casual boy Farsi. Say "چخبرا" not "چی میخوای". Don't be pushy. Keep banter light.
§
User handle: Eryy Ribu. Telegram user ID: 7299111403. Home group: -1003945495799 (named "ye zamani noon too business bood"). Friends added as allowed users: 8411411917, 7392106679, 5803589152, 7621578372.
§
User profile: Iranian teen gamer (14yo). Mid-range PC (i5-6500 + RTX 2060 Super). Far Cry 3 fan. Learning Linux, networking. No programming skills. Limited budget. Bandar Anzali. Call bot "HeryAli". Casual boy Farsi.
§
Razz: Parnian (Pourham's crush, childhood friend). She lives in Tehran, he's in Bandar Anzali. Families are friends. Never messaged each other. He found her number but hasn't texted. Her mom limits her (study focus). He wants to invite her family again and make up for not offering coffee last time.
§
Group behavior: Don't talk too much in groups. Only respond when directly mentioned or when necessary. Be quiet and minimal.